-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 09, 2016 at 05:41 AM
-- Server version: 5.5.24-log
-- PHP Version: 5.4.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `gema5`
--

-- --------------------------------------------------------

--
-- Table structure for table `accion`
--

CREATE TABLE IF NOT EXISTS `accion` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `tiempo` int(11) NOT NULL,
  `procedimiento` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `accion`
--

INSERT INTO `accion` (`id`, `nombre`, `tiempo`, `procedimiento`) VALUES
(1, 'DESTUPIR CAÑO', 1231, 'asdfsdf'),
(2, 'ACCION1', 123, '123123');

-- --------------------------------------------------------

--
-- Table structure for table `actividad`
--

CREATE TABLE IF NOT EXISTS `actividad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `direccion` longtext COLLATE utf8_unicode_ci NOT NULL,
  `tipoActividad_id` int(11) DEFAULT NULL,
  `planMtto_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_F033FA513BCBD34` (`tipoActividad_id`),
  KEY `IDX_F033FA5937FC699` (`planMtto_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `activo`
--

CREATE TABLE IF NOT EXISTS `activo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `factura_id` int(11) DEFAULT NULL,
  `area_id` int(11) DEFAULT NULL,
  `noInventario` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `noActivo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `marca` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `modelo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `fechaDepreciacion` date NOT NULL,
  `fechaInstalacion` date NOT NULL,
  `fechaPuestaMarcha` date NOT NULL,
  `fecha_Ultimo_Mtto` datetime DEFAULT NULL,
  `fecha_Proximo_Mtto` datetime DEFAULT NULL,
  `cicloMtto` int(11) NOT NULL,
  `notas` longtext COLLATE utf8_unicode_ci,
  `tipoActivo_id` int(11) NOT NULL,
  `centroCosto` longtext COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_AC67102AF04F795F` (`factura_id`),
  KEY `IDX_AC67102A328AFFA9` (`tipoActivo_id`),
  KEY `IDX_AC67102ABD0F409C` (`area_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=158 ;

--
-- Dumping data for table `activo`
--

INSERT INTO `activo` (`id`, `factura_id`, `area_id`, `noInventario`, `noActivo`, `nombre`, `marca`, `modelo`, `fechaDepreciacion`, `fechaInstalacion`, `fechaPuestaMarcha`, `fecha_Ultimo_Mtto`, `fecha_Proximo_Mtto`, `cicloMtto`, `notas`, `tipoActivo_id`, `centroCosto`) VALUES
(4, 1, 4, '123456', 'AF_XXXXX_2016_21', 'PRUEBITA', 'PRUEBITA', 'PRUEBITA', '2011-01-01', '2011-01-04', '2011-01-04', NULL, '2016-02-29 00:00:00', 3, 'Esta es una nota!!!!', 1, ''),
(5, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1415', 'sdf', 'sdf', 'sdf', '2020-04-16', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '123'),
(6, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1416', 'sdf', 'sdf', 'sdf', '2020-04-17', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '123'),
(7, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1417', 'sdf', 'sdf', 'sdf', '2020-04-18', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '124'),
(8, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1418', 'sdf', 'sdf', 'sdf', '2020-04-19', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '125'),
(9, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1419', 'sdf', 'sdf', 'sdf', '2020-04-20', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '126'),
(10, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1420', 'sdf', 'sdf', 'sdf', '2020-04-21', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '127'),
(11, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1421', 'sdf', 'sdf', 'sdf', '2020-04-22', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '128'),
(12, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1422', 'sdf', 'sdf', 'sdf', '2020-04-23', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '129'),
(13, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1423', 'sdf', 'sdf', 'sdf', '2020-04-24', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '130'),
(14, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1424', 'sdf', 'sdf', 'sdf', '2020-04-25', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '131'),
(15, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1425', 'sdf', 'sdf', 'sdf', '2020-04-26', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '132'),
(16, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1426', 'sdf', 'sdf', 'sdf', '2020-04-27', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '133'),
(17, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1427', 'sdf', 'sdf', 'sdf', '2020-04-28', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '134'),
(18, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1428', 'sdf', 'sdf', 'sdf', '2020-04-29', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '135'),
(19, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1429', 'sdf', 'sdf', 'sdf', '2020-04-30', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '136'),
(20, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1430', 'sdf', 'sdf', 'sdf', '2020-05-01', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '137'),
(21, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1431', 'sdf', 'sdf', 'sdf', '2020-05-02', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '138'),
(22, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1432', 'sdf', 'sdf', 'sdf', '2020-05-03', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '139'),
(23, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1433', 'sdf', 'sdf', 'sdf', '2020-05-04', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '140'),
(24, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1434', 'sdf', 'sdf', 'sdf', '2020-05-05', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '141'),
(25, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1435', 'sdf', 'sdf', 'sdf', '2020-05-06', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '142'),
(26, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1436', 'sdf', 'sdf', 'sdf', '2020-05-07', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '143'),
(27, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1437', 'sdf', 'sdf', 'sdf', '2020-05-08', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '144'),
(28, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1438', 'sdf', 'sdf', 'sdf', '2020-05-09', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '145'),
(29, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1439', 'sdf', 'sdf', 'sdf', '2020-05-10', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '146'),
(30, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1440', 'sdf', 'sdf', 'sdf', '2020-05-11', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '147'),
(31, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1441', 'sdf', 'sdf', 'sdf', '2020-05-12', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '148'),
(32, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1442', 'sdf', 'sdf', 'sdf', '2020-05-13', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '149'),
(33, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1443', 'sdf', 'sdf', 'sdf', '2020-05-14', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '150'),
(34, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1444', 'sdf', 'sdf', 'sdf', '2020-05-15', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '151'),
(35, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1445', 'sdf', 'sdf', 'sdf', '2020-05-16', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '152'),
(36, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1446', 'sdf', 'sdf', 'sdf', '2020-05-17', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '153'),
(37, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1447', 'sdf', 'sdf', 'sdf', '2020-05-18', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '154'),
(38, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1448', 'sdf', 'sdf', 'sdf', '2020-05-19', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '155'),
(39, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1449', 'sdf', 'sdf', 'sdf', '2020-05-20', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '156'),
(40, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1450', 'sdf', 'sdf', 'sdf', '2020-05-21', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '157'),
(41, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1451', 'sdf', 'sdf', 'sdf', '2020-05-22', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '158'),
(42, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1452', 'sdf', 'sdf', 'sdf', '2020-05-23', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '159'),
(43, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1453', 'sdf', 'sdf', 'sdf', '2020-05-24', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '160'),
(44, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1454', 'sdf', 'sdf', 'sdf', '2020-05-25', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '161'),
(45, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1455', 'sdf', 'sdf', 'sdf', '2020-05-26', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '162'),
(46, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1456', 'sdf', 'sdf', 'sdf', '2020-05-27', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '163'),
(47, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1457', 'sdf', 'sdf', 'sdf', '2020-05-28', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '164'),
(48, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1458', 'sdf', 'sdf', 'sdf', '2020-05-29', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '165'),
(49, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1459', 'sdf', 'sdf', 'sdf', '2020-05-30', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '166'),
(50, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1460', 'sdf', 'sdf', 'sdf', '2020-05-31', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '167'),
(51, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1461', 'sdf', 'sdf', 'sdf', '2020-06-01', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '168'),
(52, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1462', 'sdf', 'sdf', 'sdf', '2020-06-02', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '169'),
(53, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1463', 'sdf', 'sdf', 'sdf', '2020-06-03', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '170'),
(54, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1464', 'sdf', 'sdf', 'sdf', '2020-06-04', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '171'),
(55, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1465', 'sdf', 'sdf', 'sdf', '2020-06-05', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '172'),
(56, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1466', 'sdf', 'sdf', 'sdf', '2020-06-06', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '173'),
(57, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1467', 'sdf', 'sdf', 'sdf', '2020-06-07', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '174'),
(58, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1468', 'sdf', 'sdf', 'sdf', '2020-06-08', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '175'),
(59, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1469', 'sdf', 'sdf', 'sdf', '2020-06-09', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '176'),
(60, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1470', 'sdf', 'sdf', 'sdf', '2020-06-10', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '177'),
(61, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1471', 'sdf', 'sdf', 'sdf', '2020-06-11', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '178'),
(62, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1472', 'sdf', 'sdf', 'sdf', '2020-06-12', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '179'),
(63, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1473', 'sdf', 'sdf', 'sdf', '2020-06-13', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '180'),
(64, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1474', 'sdf', 'sdf', 'sdf', '2020-06-14', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '181'),
(65, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1475', 'sdf', 'sdf', 'sdf', '2020-06-15', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '182'),
(66, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1476', 'sdf', 'sdf', 'sdf', '2020-06-16', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '183'),
(67, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1477', 'sdf', 'sdf', 'sdf', '2020-06-17', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '184'),
(68, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1478', 'sdf', 'sdf', 'sdf', '2020-06-18', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '185'),
(69, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1479', 'sdf', 'sdf', 'sdf', '2020-06-19', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '186'),
(70, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1480', 'sdf', 'sdf', 'sdf', '2020-06-20', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '187'),
(71, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1481', 'sdf', 'sdf', 'sdf', '2020-06-21', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '188'),
(72, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1482', 'sdf', 'sdf', 'sdf', '2020-06-22', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '189'),
(73, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1483', 'sdf', 'sdf', 'sdf', '2020-06-23', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '190'),
(74, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1484', 'sdf', 'sdf', 'sdf', '2020-06-24', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '191'),
(75, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1485', 'sdf', 'sdf', 'sdf', '2020-06-25', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '192'),
(76, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1486', 'sdf', 'sdf', 'sdf', '2020-06-26', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '193'),
(77, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1487', 'sdf', 'sdf', 'sdf', '2020-06-27', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '194'),
(78, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1488', 'sdf', 'sdf', 'sdf', '2020-06-28', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '195'),
(79, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1489', 'sdf', 'sdf', 'sdf', '2020-06-29', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '196'),
(80, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1490', 'sdf', 'sdf', 'sdf', '2020-06-30', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '197'),
(81, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1491', 'sdf', 'sdf', 'sdf', '2020-07-01', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '198'),
(82, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1492', 'sdf', 'sdf', 'sdf', '2020-07-02', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '199'),
(83, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1493', 'sdf', 'sdf', 'sdf', '2020-07-03', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '200'),
(84, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1494', 'sdf', 'sdf', 'sdf', '2020-07-04', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '201'),
(85, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1495', 'sdf', 'sdf', 'sdf', '2020-07-05', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '202'),
(86, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1496', 'sdf', 'sdf', 'sdf', '2020-07-06', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '203'),
(87, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1497', 'sdf', 'sdf', 'sdf', '2020-07-07', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '204'),
(88, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1498', 'sdf', 'sdf', 'sdf', '2020-07-08', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '205'),
(89, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1499', 'sdf', 'sdf', 'sdf', '2020-07-09', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '206'),
(90, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1500', 'sdf', 'sdf', 'sdf', '2020-07-10', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '207'),
(91, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1501', 'sdf', 'sdf', 'sdf', '2020-07-11', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '208'),
(92, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1502', 'sdf', 'sdf', 'sdf', '2020-07-12', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '209'),
(93, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1503', 'sdf', 'sdf', 'sdf', '2020-07-13', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '210'),
(94, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1504', 'sdf', 'sdf', 'sdf', '2020-07-14', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '211'),
(95, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1505', 'sdf', 'sdf', 'sdf', '2020-07-15', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '212'),
(96, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1506', 'sdf', 'sdf', 'sdf', '2020-07-16', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '213'),
(97, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1507', 'sdf', 'sdf', 'sdf', '2020-07-17', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '214'),
(98, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1508', 'sdf', 'sdf', 'sdf', '2020-07-18', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '215'),
(99, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1509', 'sdf', 'sdf', 'sdf', '2020-07-19', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '216'),
(100, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1510', 'sdf', 'sdf', 'sdf', '2020-07-20', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '217'),
(101, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1511', 'sdf', 'sdf', 'sdf', '2020-07-21', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '218'),
(102, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1512', 'sdf', 'sdf', 'sdf', '2020-07-22', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '219'),
(103, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1513', 'sdf', 'sdf', 'sdf', '2020-07-23', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '220'),
(104, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1514', 'sdf', 'sdf', 'sdf', '2020-07-24', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '221'),
(105, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1515', 'sdf', 'sdf', 'sdf', '2020-07-25', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '222'),
(106, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1516', 'sdf', 'sdf', 'sdf', '2020-07-26', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '223'),
(107, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1517', 'sdf', 'sdf', 'sdf', '2020-07-27', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '224'),
(108, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1518', 'sdf', 'sdf', 'sdf', '2020-07-28', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '225'),
(109, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1519', 'sdf', 'sdf', 'sdf', '2020-07-29', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '226'),
(110, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1520', 'sdf', 'sdf', 'sdf', '2020-07-30', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '227'),
(111, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1521', 'sdf', 'sdf', 'sdf', '2020-07-31', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '228'),
(112, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1522', 'sdf', 'sdf', 'sdf', '2020-08-01', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '229'),
(113, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1523', 'sdf', 'sdf', 'sdf', '2020-08-02', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '230'),
(114, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1524', 'sdf', 'sdf', 'sdf', '2020-08-03', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '231'),
(115, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1525', 'sdf', 'sdf', 'sdf', '2020-08-04', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '232'),
(116, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1526', 'sdf', 'sdf', 'sdf', '2020-08-05', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '233'),
(117, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1527', 'sdf', 'sdf', 'sdf', '2020-08-06', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '234'),
(118, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1528', 'sdf', 'sdf', 'sdf', '2020-08-07', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '235'),
(119, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1529', 'sdf', 'sdf', 'sdf', '2020-08-08', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '236'),
(120, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1530', 'sdf', 'sdf', 'sdf', '2020-08-09', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '237'),
(121, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1531', 'sdf', 'sdf', 'sdf', '2020-08-10', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '238'),
(122, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1532', 'sdf', 'sdf', 'sdf', '2020-08-11', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '239'),
(123, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1533', 'sdf', 'sdf', 'sdf', '2020-08-12', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '240'),
(124, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1534', 'sdf', 'sdf', 'sdf', '2020-08-13', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '241'),
(125, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1535', 'sdf', 'sdf', 'sdf', '2020-08-14', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '242'),
(126, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1536', 'sdf', 'sdf', 'sdf', '2020-08-15', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '243'),
(127, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1537', 'sdf', 'sdf', 'sdf', '2020-08-16', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '244'),
(128, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1538', 'sdf', 'sdf', 'sdf', '2020-08-17', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '245'),
(129, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1539', 'sdf', 'sdf', 'sdf', '2020-08-18', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '246'),
(130, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1540', 'sdf', 'sdf', 'sdf', '2020-08-19', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '247'),
(131, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1541', 'sdf', 'sdf', 'sdf', '2020-08-20', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '248'),
(132, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1542', 'sdf', 'sdf', 'sdf', '2020-08-21', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '249'),
(133, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1543', 'sdf', 'sdf', 'sdf', '2020-08-22', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '250'),
(134, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1544', 'sdf', 'sdf', 'sdf', '2020-08-23', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '251'),
(135, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1545', 'sdf', 'sdf', 'sdf', '2020-08-24', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '252'),
(136, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1546', 'sdf', 'sdf', 'sdf', '2020-08-25', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '253'),
(137, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1547', 'sdf', 'sdf', 'sdf', '2020-08-26', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '254'),
(138, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1548', 'sdf', 'sdf', 'sdf', '2020-08-27', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '255'),
(139, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1549', 'sdf', 'sdf', 'sdf', '2020-08-28', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '256'),
(140, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1550', 'sdf', 'sdf', 'sdf', '2020-08-29', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '257'),
(141, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1551', 'sdf', 'sdf', 'sdf', '2020-08-30', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '258'),
(142, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1552', 'sdf', 'sdf', 'sdf', '2020-08-31', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '259'),
(143, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1553', 'sdf', 'sdf', 'sdf', '2020-09-01', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '260'),
(144, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1554', 'sdf', 'sdf', 'sdf', '2020-09-02', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '261'),
(145, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1555', 'sdf', 'sdf', 'sdf', '2020-09-03', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '262'),
(146, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1556', 'sdf', 'sdf', 'sdf', '2020-09-04', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '263'),
(147, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1557', 'sdf', 'sdf', 'sdf', '2020-09-05', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '264'),
(148, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1558', 'sdf', 'sdf', 'sdf', '2020-09-06', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '265'),
(149, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1559', 'sdf', 'sdf', 'sdf', '2020-09-07', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '266'),
(150, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1560', 'sdf', 'sdf', 'sdf', '2020-09-08', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '267'),
(151, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1561', 'sdf', 'sdf', 'sdf', '2020-09-09', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '268'),
(152, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1562', 'sdf', 'sdf', 'sdf', '2020-09-10', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '269'),
(153, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1563', 'sdf', 'sdf', 'sdf', '2020-09-11', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '270'),
(154, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1564', 'sdf', 'sdf', 'sdf', '2020-09-12', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '271'),
(155, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1565', 'sdf', 'sdf', 'sdf', '2020-09-13', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '272'),
(156, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1566', 'sdf', 'sdf', 'sdf', '2020-09-14', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '273'),
(157, NULL, NULL, 'sdf', 'AF_XXXXX_2016_1567', 'sdf', 'sdf', 'sdf', '2020-09-15', '2016-04-16', '2016-04-16', NULL, NULL, 1, NULL, 1, '274');

-- --------------------------------------------------------

--
-- Table structure for table `area`
--

CREATE TABLE IF NOT EXISTS `area` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_77A692563A909126` (`nombre`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `area`
--

INSERT INTO `area` (`id`, `nombre`) VALUES
(1, 'Desarrollo'),
(4, 'Economía'),
(2, 'Implantación');

-- --------------------------------------------------------

--
-- Table structure for table `estop`
--

CREATE TABLE IF NOT EXISTS `estop` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activo_id` int(11) DEFAULT NULL,
  `desde` datetime NOT NULL,
  `hasta` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_5BA7CD2C487E62A3` (`activo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `estop`
--

INSERT INTO `estop` (`id`, `activo_id`, `desde`, `hasta`) VALUES
(2, 4, '2016-03-12 04:00:00', '2016-03-12 06:00:00'),
(3, 4, '2016-01-01 07:00:00', '2016-01-01 08:00:00'),
(4, 4, '2016-01-03 09:00:00', '2016-01-03 10:00:00'),
(5, 4, '2016-01-04 11:00:00', '2016-01-04 12:00:00'),
(6, 4, '2016-01-05 13:00:00', '2016-01-05 14:00:00'),
(7, 4, '2016-01-03 13:01:00', '2016-01-03 23:59:00');

-- --------------------------------------------------------

--
-- Table structure for table `factura`
--

CREATE TABLE IF NOT EXISTS `factura` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `precio` double NOT NULL,
  `codigo` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_36569995CB305D73` (`proveedor_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `factura`
--

INSERT INTO `factura` (`id`, `proveedor_id`, `fecha`, `precio`, `codigo`) VALUES
(1, 1, '2016-02-20', 789, '1231');

-- --------------------------------------------------------

--
-- Table structure for table `herramienta`
--

CREATE TABLE IF NOT EXISTS `herramienta` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `costo_unitario` double NOT NULL,
  `depreciacion_diaria` double NOT NULL,
  `norma` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `herramienta`
--

INSERT INTO `herramienta` (`id`, `nombre`, `costo_unitario`, `depreciacion_diaria`, `norma`) VALUES
(1, 'Carretilla', 100.5, 0.1, 0.01);

-- --------------------------------------------------------

--
-- Table structure for table `insumo`
--

CREATE TABLE IF NOT EXISTS `insumo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `um` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `costo_unitario` double NOT NULL,
  `depreciacion_diaria` double NOT NULL,
  `norma` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `insumo`
--

INSERT INTO `insumo` (`id`, `nombre`, `um`, `costo_unitario`, `depreciacion_diaria`, `norma`) VALUES
(1, 'Paño de Limpieza', 'U', 10.2, 0.2, 0.02),
(2, 'sdds', 'U', 10, 0.1, 0.1);

-- --------------------------------------------------------

--
-- Table structure for table `material`
--

CREATE TABLE IF NOT EXISTS `material` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `costoUnitario` double NOT NULL,
  `um` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `ordentrabajo`
--

CREATE TABLE IF NOT EXISTS `ordentrabajo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `costoTotal` double NOT NULL,
  `tiempoTotal` double NOT NULL,
  `planMtto_id` int(11) DEFAULT NULL,
  `cumplida` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_3BF2895C937FC699` (`planMtto_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `ordentrabajo`
--

INSERT INTO `ordentrabajo` (`id`, `nombre`, `costoTotal`, `tiempoTotal`, `planMtto_id`, `cumplida`) VALUES
(1, 'PRUEBA Numero 1', 22374.7, 312, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `ordentrabajo_procedimiento`
--

CREATE TABLE IF NOT EXISTS `ordentrabajo_procedimiento` (
  `ordentrabajo_id` int(11) NOT NULL,
  `procedimiento_id` int(11) NOT NULL,
  PRIMARY KEY (`ordentrabajo_id`,`procedimiento_id`),
  KEY `IDX_1E60AF3F7D8D9FA3` (`ordentrabajo_id`),
  KEY `IDX_1E60AF3FF696A255` (`procedimiento_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `ordentrabajo_procedimiento`
--

INSERT INTO `ordentrabajo_procedimiento` (`ordentrabajo_id`, `procedimiento_id`) VALUES
(1, 1),
(1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `otrep`
--

CREATE TABLE IF NOT EXISTS `otrep` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `repuesto_id` int(11) DEFAULT NULL,
  `procedimiento_id` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `costo` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_DF6B1B4E4C3B689E` (`repuesto_id`),
  KEY `IDX_DF6B1B4EF696A255` (`procedimiento_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `otrep`
--

INSERT INTO `otrep` (`id`, `repuesto_id`, `procedimiento_id`, `cantidad`, `costo`) VALUES
(1, 1, 1, 123, 18474.6),
(2, 1, 2, 20, 3004);

-- --------------------------------------------------------

--
-- Table structure for table `persona`
--

CREATE TABLE IF NOT EXISTS `persona` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) DEFAULT NULL,
  `cIdentidad` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sexo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `direccion` longtext COLLATE utf8_unicode_ci,
  `cargo` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `salario` double NOT NULL,
  `gastoDia` double NOT NULL,
  `gastoHora` double NOT NULL,
  `gastoMinuto` double NOT NULL,
  `profesion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9E588F07DB38439E` (`usuario_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `planmtto`
--

CREATE TABLE IF NOT EXISTS `planmtto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `fecha` date NOT NULL,
  `tipoPrioridad_id` int(11) DEFAULT NULL,
  `activo_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_35609FBACE797A84` (`tipoPrioridad_id`),
  KEY `IDX_35609FBA487E62A3` (`activo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `planmtto`
--

INSERT INTO `planmtto` (`id`, `nombre`, `fecha`, `tipoPrioridad_id`, `activo_id`) VALUES
(1, 'REPARACION DE CALDERA A PRUEBITA1', '2016-02-19', 7, 4),
(2, 'PRRR', '2016-02-29', 5, 4);

-- --------------------------------------------------------

--
-- Table structure for table `procedimiento`
--

CREATE TABLE IF NOT EXISTS `procedimiento` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `organizacionProductiva` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tiempoTotal` double DEFAULT NULL,
  `costoTotal` double DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `procedimiento`
--

INSERT INTO `procedimiento` (`id`, `codigo`, `nombre`, `organizacionProductiva`, `tiempoTotal`, `costoTotal`) VALUES
(1, '123', 'LIMPIA TUBERIA', 'asda', 234, 18474.6),
(2, '7894', 'PROC1', 'CASA', 78, 3900.1);

-- --------------------------------------------------------

--
-- Table structure for table `procedimiento_accion`
--

CREATE TABLE IF NOT EXISTS `procedimiento_accion` (
  `procedimiento_id` int(11) NOT NULL,
  `accion_id` int(11) NOT NULL,
  PRIMARY KEY (`procedimiento_id`,`accion_id`),
  KEY `IDX_C271E3FF696A255` (`procedimiento_id`),
  KEY `IDX_C271E3F3F4B5275` (`accion_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `procedimiento_accion`
--

INSERT INTO `procedimiento_accion` (`procedimiento_id`, `accion_id`) VALUES
(1, 1),
(2, 1),
(2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `proher`
--

CREATE TABLE IF NOT EXISTS `proher` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `procedimiento_id` int(11) DEFAULT NULL,
  `herramienta_id` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `costo` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_8513AE24F696A255` (`procedimiento_id`),
  KEY `IDX_8513AE24B2C900C2` (`herramienta_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `proher`
--

INSERT INTO `proher` (`id`, `procedimiento_id`, `herramienta_id`, `cantidad`, `costo`) VALUES
(1, 2, 1, 1, 100.5);

-- --------------------------------------------------------

--
-- Table structure for table `proins`
--

CREATE TABLE IF NOT EXISTS `proins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `procedimiento_id` int(11) DEFAULT NULL,
  `insumo_id` int(11) DEFAULT NULL,
  `cantidad` int(11) NOT NULL,
  `costo` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_10222D4EF696A255` (`procedimiento_id`),
  KEY `IDX_10222D4ECE208F97` (`insumo_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `proins`
--

INSERT INTO `proins` (`id`, `procedimiento_id`, `insumo_id`, `cantidad`, `costo`) VALUES
(1, 2, 1, 78, 795.6);

-- --------------------------------------------------------

--
-- Table structure for table `proper`
--

CREATE TABLE IF NOT EXISTS `proper` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `procedimiento_id` int(11) DEFAULT NULL,
  `persona_id` int(11) DEFAULT NULL,
  `tiempo` double NOT NULL,
  `costo` double NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_97265CECF696A255` (`procedimiento_id`),
  KEY `IDX_97265CECF5F88DB9` (`persona_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `proveedor`
--

CREATE TABLE IF NOT EXISTS `proveedor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `proveedor` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `direccion` longtext COLLATE utf8_unicode_ci,
  `telefono` varchar(25) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `proveedor`
--

INSERT INTO `proveedor` (`id`, `proveedor`, `email`, `direccion`, `telefono`) VALUES
(1, 'Desoft', 'comercial@desoft.cu', 'Calle 24, No. 562, Vedado, La Habana', '7 836 5492');

-- --------------------------------------------------------

--
-- Table structure for table `repuesto`
--

CREATE TABLE IF NOT EXISTS `repuesto` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `um` varchar(3) COLLATE utf8_unicode_ci DEFAULT NULL,
  `costo_unitario` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `repuesto`
--

INSERT INTO `repuesto` (`id`, `nombre`, `um`, `costo_unitario`) VALUES
(1, 'Capacitor', 'U', 150.2);

-- --------------------------------------------------------

--
-- Table structure for table `rol`
--

CREATE TABLE IF NOT EXISTS `rol` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- Dumping data for table `rol`
--

INSERT INTO `rol` (`id`, `nombre`, `descripcion`) VALUES
(4, 'ROLE_ADMINISTRADOR', 'Administrador'),
(5, 'ROLE_MANTENIMIENTO', 'Responsable de Mantenimiento'),
(6, 'ROLE_OPERACIONES', 'Responsable de Operaciones'),
(7, 'ROLE_ALMACENERO', 'Almacenero');

-- --------------------------------------------------------

--
-- Table structure for table `tipoactividad`
--

CREATE TABLE IF NOT EXISTS `tipoactividad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tipo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `tipoactivo`
--

CREATE TABLE IF NOT EXISTS `tipoactivo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `codificador` varchar(5) COLLATE utf8_unicode_ci NOT NULL,
  `TipoActivo` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_6FBE65AEC553CB22` (`codificador`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tipoactivo`
--

INSERT INTO `tipoactivo` (`id`, `codificador`, `TipoActivo`) VALUES
(1, 'XXXXX', 'dsfdsfdsfdsfsdds111');

-- --------------------------------------------------------

--
-- Table structure for table `tipoprioridad`
--

CREATE TABLE IF NOT EXISTS `tipoprioridad` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prioridad` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tipoprioridad`
--

INSERT INTO `tipoprioridad` (`id`, `prioridad`, `descripcion`) VALUES
(5, 'NORMAL', 'El mantenimiento debe comenzar dentro de las próximas 48H'),
(6, 'EMERGENCIA', 'El mantenimiento debe comenzar de inmediato'),
(7, 'URGENTE', 'El mantenimiento debe comenzar dentro de las próximas 24H'),
(8, 'APLAZABLE', 'Cuando se cuente con los recursos o en el período de una parada');

-- --------------------------------------------------------

--
-- Table structure for table `traza`
--

CREATE TABLE IF NOT EXISTS `traza` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nivel` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `accion` longtext COLLATE utf8_unicode_ci NOT NULL,
  `fecha` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=446 ;

--
-- Dumping data for table `traza`
--

INSERT INTO `traza` (`id`, `nivel`, `accion`, `fecha`) VALUES
(4, 'admin', 'Listar Roles de Usuario', '2016-02-04 18:20:45'),
(5, 'admin', 'Listar Usuarios del Sistema', '2016-02-04 18:21:27'),
(6, 'admin', 'Nuevo Usuario: rolando', '2016-02-04 18:22:20'),
(7, 'admin', 'Listar Usuarios del Sistema', '2016-02-04 18:22:21'),
(8, 'rolando', 'Listar Usuarios del Sistema', '2016-02-04 18:23:32'),
(9, 'rolando', 'Nuevo Usuario: gisselle', '2016-02-04 18:23:59'),
(10, 'rolando', 'Listar Usuarios del Sistema', '2016-02-04 18:24:00'),
(11, 'rolando', 'Borrar Usuario: rolando', '2016-02-04 18:24:10'),
(12, 'rolando', 'Listar Usuarios del Sistema', '2016-02-04 18:24:56'),
(13, 'rolando', 'Listar Usuarios del Sistema', '2016-02-04 18:25:07'),
(14, 'rolando', 'Borrar Usuario: rolando', '2016-02-04 18:25:11'),
(15, 'rolando', 'Listar Usuarios del Sistema', '2016-02-04 18:25:25'),
(16, 'gisselle', 'Listar Expedientes de Activos', '2016-02-04 18:26:51'),
(17, 'gisselle', 'Listar Expedientes de Activos', '2016-02-04 18:27:43'),
(18, 'gisselle', 'Listar Planes de Mantenimiento', '2016-02-04 18:29:32'),
(19, 'admin', 'Listar Usuarios del Sistema', '2016-02-04 20:42:31'),
(20, 'admin', 'Listar Áreas', '2016-02-04 21:34:03'),
(21, 'admin', 'Listar Áreas', '2016-02-04 21:45:29'),
(22, 'admin', 'Listar Roles de Usuario', '2016-02-04 21:45:37'),
(23, 'admin', 'Listar Áreas', '2016-02-04 21:46:24'),
(24, 'admin', 'Listar Áreas', '2016-02-04 21:55:33'),
(25, 'admin', 'Nueva Área: Desarrollo', '2016-02-04 21:56:15'),
(26, 'admin', 'Listar Áreas', '2016-02-04 21:56:16'),
(27, 'admin', 'Listar Áreas', '2016-02-04 21:56:53'),
(28, 'admin', 'Editar Área: Desarrollo', '2016-02-04 21:57:11'),
(29, 'admin', 'Listar Áreas', '2016-02-04 21:57:12'),
(30, 'admin', 'Editar Área: Desarrollo', '2016-02-04 21:58:16'),
(31, 'admin', 'Listar Áreas', '2016-02-04 21:58:17'),
(32, 'admin', 'Editar Área: Desarrollo', '2016-02-04 21:59:23'),
(33, 'admin', 'Listar Áreas', '2016-02-04 21:59:24'),
(34, 'admin', 'Editar Área: Desarrollo', '2016-02-04 21:59:39'),
(35, 'admin', 'Listar Áreas', '2016-02-04 21:59:40'),
(36, 'admin', 'Listar Áreas', '2016-02-04 22:00:43'),
(37, 'admin', 'Editar Área: Desarrollo', '2016-02-04 22:00:53'),
(38, 'admin', 'Listar Áreas', '2016-02-04 22:00:54'),
(39, 'admin', 'Listar Áreas', '2016-02-04 22:03:33'),
(40, 'admin', 'Listar Áreas', '2016-02-05 01:33:56'),
(41, 'admin', 'Listar Áreas', '2016-02-05 02:00:18'),
(42, 'admin', 'Listar Expedientes de Accion', '2016-02-05 02:08:27'),
(43, 'admin', 'Listar Áreas', '2016-02-05 02:09:11'),
(44, 'admin', 'Nueva Área: Implantación', '2016-02-05 02:09:30'),
(45, 'admin', 'Listar Áreas', '2016-02-05 02:09:32'),
(46, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 02:18:03'),
(47, 'admin', 'Listar Áreas', '2016-02-05 02:19:08'),
(48, 'admin', 'Listar Áreas', '2016-02-05 02:26:35'),
(49, 'admin', 'Listar Áreas', '2016-02-05 02:26:52'),
(50, 'admin', 'Nueva Área: Desarrollo', '2016-02-05 02:43:26'),
(51, 'admin', 'Nueva Área: Economía', '2016-02-05 02:45:00'),
(52, 'admin', 'Listar Áreas', '2016-02-05 02:45:01'),
(53, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 02:45:47'),
(54, 'admin', '', '2016-02-05 02:51:52'),
(55, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 02:51:52'),
(56, 'admin', ' ', '2016-02-05 02:53:19'),
(57, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 02:53:20'),
(58, 'admin', ' ', '2016-02-05 02:53:46'),
(59, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 02:53:47'),
(60, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 02:55:23'),
(61, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 02:58:13'),
(62, 'admin', ' ', '2016-02-05 02:58:35'),
(63, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 02:58:36'),
(64, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 02:58:56'),
(65, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 02:59:32'),
(66, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 03:00:38'),
(67, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 03:01:45'),
(68, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 03:01:59'),
(69, 'admin', 'Listar Tipos de Activos', '2016-02-05 03:02:08'),
(70, 'admin', 'Listar Expedientes de Proveedor', '2016-02-05 03:02:26'),
(71, 'admin', 'Listar Tipos de Activos', '2016-02-05 03:03:28'),
(72, 'admin', 'Listar Tipos de Activos', '2016-02-05 03:03:56'),
(73, 'admin', 'Nuevo Tipo de Activo: wewrwerwe', '2016-02-05 03:27:29'),
(74, 'admin', 'Listar Tipos de Activos', '2016-02-05 03:27:30'),
(75, 'admin', 'Editar Tipo de Activo: XXXXX', '2016-02-05 03:34:45'),
(76, 'admin', 'Listar Tipos de Activos', '2016-02-05 03:34:46'),
(77, 'admin', 'Listar Tipos de Activos', '2016-02-05 03:43:17'),
(78, 'admin', 'Listar Tipos de Activos', '2016-02-05 03:49:39'),
(79, 'admin', 'Listar Tipos de Activos', '2016-02-05 03:50:23'),
(80, 'admin', 'Listar Tipos de Activos', '2016-02-05 03:57:10'),
(81, 'admin', 'Listar Expedientes de Herramienta', '2016-02-05 03:57:21'),
(82, 'admin', 'Listar Expedientes de Herramienta', '2016-02-05 03:59:35'),
(83, 'admin', '', '2016-02-05 04:14:28'),
(84, 'admin', 'Listar Expedientes de Herramienta', '2016-02-05 04:14:29'),
(85, 'admin', 'Listar Expedientes de Herramienta', '2016-02-05 04:16:15'),
(86, 'admin', ' ', '2016-02-05 04:18:09'),
(87, 'admin', 'Listar Expedientes de Herramienta', '2016-02-05 04:18:10'),
(88, 'admin', 'Listar Expedientes de Herramienta', '2016-02-05 04:23:22'),
(89, 'admin', 'Listar Expedientes de Insumo', '2016-02-05 04:24:19'),
(90, 'admin', 'Listar Expedientes de Herramienta', '2016-02-05 04:24:29'),
(91, 'admin', 'Listar Expedientes de Herramienta', '2016-02-05 04:24:39'),
(92, 'admin', 'Listar Expedientes de Insumo', '2016-02-05 04:26:06'),
(93, 'admin', 'Listar Expedientes de Insumo', '2016-02-05 04:26:53'),
(94, 'admin', '', '2016-02-05 04:42:00'),
(95, 'admin', 'Listar Expedientes de Insumo', '2016-02-05 04:42:01'),
(96, 'admin', 'Listar Expedientes de Insumo', '2016-02-05 04:43:02'),
(97, 'admin', ' ', '2016-02-05 04:43:47'),
(98, 'admin', 'Listar Expedientes de Insumo', '2016-02-05 04:43:47'),
(99, 'admin', 'Listar Expedientes de Insumo', '2016-02-05 04:45:56'),
(100, 'admin', 'Listar Repuestos', '2016-02-05 04:46:30'),
(101, 'admin', 'Listar Repuestos', '2016-02-05 04:48:38'),
(102, 'admin', 'Listar Expedientes de Insumo', '2016-02-05 04:49:40'),
(103, 'admin', '', '2016-02-05 04:52:40'),
(104, 'admin', '', '2016-02-05 04:53:45'),
(105, 'admin', 'Listar Expedientes de Insumo', '2016-02-05 04:53:46'),
(106, 'admin', 'Listar Expedientes de Insumo', '2016-02-05 04:58:12'),
(107, 'admin', ' ', '2016-02-05 04:58:27'),
(108, 'admin', 'Listar Expedientes de Insumo', '2016-02-05 04:58:28'),
(109, 'admin', 'Listar Repuestos', '2016-02-05 04:58:33'),
(110, 'admin', 'Listar Repuestos', '2016-02-05 05:00:27'),
(111, 'admin', 'Nuevo Repuesto: Capacitor', '2016-02-05 05:00:40'),
(112, 'admin', 'Listar Repuestos', '2016-02-05 05:00:41'),
(113, 'admin', 'Listar Repuestos', '2016-02-05 05:00:43'),
(114, 'admin', 'Listar Repuestos', '2016-02-05 05:02:04'),
(115, 'admin', 'Listar Repuestos', '2016-02-05 05:02:07'),
(116, 'admin', 'Listar Tipos de Prioridad', '2016-02-05 05:02:20'),
(117, 'admin', 'Listar Tipos de Prioridad', '2016-02-05 05:04:36'),
(118, 'admin', 'Editar Tipo de Prioridad: EMERGENCIA', '2016-02-05 05:05:55'),
(119, 'admin', 'Listar Tipos de Prioridad', '2016-02-05 05:05:56'),
(120, 'admin', 'Nuevo Tipo de Prioridad: fddsds', '2016-02-05 05:07:15'),
(121, 'admin', 'Listar Tipos de Prioridad', '2016-02-05 05:07:16'),
(122, 'admin', 'Editar Tipo de Prioridad: fddsds', '2016-02-05 05:07:42'),
(123, 'admin', 'Listar Tipos de Prioridad', '2016-02-05 05:07:43'),
(124, 'admin', 'Borrar Tipo de Prioridad: fddsds', '2016-02-05 05:07:48'),
(125, 'admin', 'Listar Tipos de Prioridad', '2016-02-05 05:07:49'),
(126, 'admin', 'Listar Facturas', '2016-02-05 05:09:27'),
(127, 'admin', 'Listar Facturas', '2016-02-05 05:14:56'),
(128, 'admin', 'Listar Facturas', '2016-02-05 05:26:11'),
(129, 'admin', 'Listar Facturas', '2016-02-05 05:32:21'),
(130, 'admin', 'Listar Facturas', '2016-02-05 05:33:00'),
(131, 'admin', 'Listar Facturas', '2016-02-05 05:33:18'),
(132, 'admin', 'Listar Órdenes de Trabajo', '2016-02-05 05:37:16'),
(133, 'admin', 'Listar Áreas', '2016-02-07 18:57:49'),
(134, 'admin', 'Listar Facturas', '2016-02-07 18:57:57'),
(135, 'admin', 'Listar Facturas', '2016-02-07 18:58:08'),
(136, 'admin', 'Listar Planes de Mantenimiento', '2016-02-07 18:58:15'),
(137, 'admin', 'Listar Planes de Mantenimiento', '2016-02-07 18:58:26'),
(138, 'admin', 'Listar Expedientes de Procedimiento', '2016-02-07 19:00:00'),
(139, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:01:25'),
(140, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:03:07'),
(141, 'admin', 'Editar Usuario: rolando', '2016-02-07 19:03:44'),
(142, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:03:46'),
(143, 'admin', 'Editar Usuario: gisselle', '2016-02-07 19:04:04'),
(144, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:04:06'),
(145, 'admin', 'Editar Usuario: gisselle', '2016-02-07 19:04:28'),
(146, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:04:30'),
(147, 'gisselle', 'Listar Expedientes de Accion', '2016-02-07 19:16:30'),
(148, 'gisselle', 'Listar Expedientes de Procedimiento', '2016-02-07 19:16:41'),
(149, 'gisselle', 'Listar Órdenes de Trabajo', '2016-02-07 19:16:50'),
(150, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:17:28'),
(151, 'admin', 'Nuevo Usuario: almacenero', '2016-02-07 19:17:58'),
(152, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:18:00'),
(153, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:18:51'),
(154, 'admin', 'Editar Usuario: almacenero1', '2016-02-07 19:19:11'),
(155, 'admin', 'Editar Usuario: almacenero1', '2016-02-07 19:19:21'),
(156, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:19:23'),
(157, 'almacenero1', 'Nueva Factura: 1231', '2016-02-07 19:20:36'),
(158, 'almacenero1', 'Ver Factura: 1231', '2016-02-07 19:20:38'),
(159, 'almacenero1', 'Listar Facturas', '2016-02-07 19:20:45'),
(160, 'almacenero1', 'Listar Facturas', '2016-02-07 19:20:50'),
(161, 'almacenero1', 'Listar Facturas', '2016-02-07 19:21:44'),
(162, 'almacenero1', 'Listar Facturas', '2016-02-07 19:21:48'),
(163, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:24:54'),
(164, 'rolando', 'Listar Usuarios del Sistema', '2016-02-07 19:25:35'),
(165, 'rolando', 'Borrar Usuario: rolando', '2016-02-07 19:25:46'),
(166, 'rolando', 'Borrar Usuario: rolando', '2016-02-07 19:34:11'),
(167, 'rolando', 'Borrar Usuario: rolando', '2016-02-07 19:34:26'),
(168, 'rolando', 'Borrar Usuario: rolando', '2016-02-07 19:38:02'),
(169, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:38:24'),
(170, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:38:29'),
(171, 'admin', 'Nuevo Usuario: rolando', '2016-02-07 19:39:32'),
(172, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 19:39:34'),
(173, 'admin', 'Listar Usuarios del Sistema', '2016-02-07 20:10:14'),
(174, 'gisselle', 'Listar Planes de Mantenimiento', '2016-02-07 20:13:01'),
(175, 'gisselle', 'Listar Planes de Mantenimiento', '2016-02-07 20:35:48'),
(176, 'gisselle', 'Listar Planes de Mantenimiento', '2016-02-07 20:47:13'),
(177, 'gisselle', 'Listar Expedientes de Accion', '2016-02-07 20:47:44'),
(178, 'gisselle', 'Listar Expedientes de Procedimiento', '2016-02-07 20:47:58'),
(179, 'gisselle', 'Listar Expedientes de Accion', '2016-02-07 20:48:51'),
(180, 'admin', 'Listar Expedientes de Activos', '2016-02-07 21:05:21'),
(181, 'admin', 'Listar Expedientes de Activos', '2016-02-07 21:06:42'),
(182, 'admin', 'Nuevo Expediente de Activo: dsfg', '2016-02-07 21:36:44'),
(183, 'admin', 'Nuevo Expediente de Activo: dsfg', '2016-02-07 21:46:03'),
(184, 'admin', 'Ver Expediente de Activo: dsfg', '2016-02-07 21:46:06'),
(185, 'admin', 'Nuevo Plan de Mantenimiento: fhfg', '2016-02-07 21:50:31'),
(186, 'admin', 'Nuevo Plan de Mantenimiento: fhfg', '2016-02-07 21:51:11'),
(187, 'admin', 'Listar Planes de Mantenimiento', '2016-02-07 21:51:13'),
(188, 'admin', 'Listar Expedientes de Procedimiento', '2016-02-07 21:51:37'),
(189, 'admin', 'Listar Expedientes de Accion', '2016-02-07 21:52:24'),
(190, 'admin', '', '2016-02-07 21:52:43'),
(191, 'admin', 'Listar Expedientes de Accion', '2016-02-07 21:52:45'),
(192, 'admin', '', '2016-02-07 21:54:31'),
(193, 'admin', ' ', '2016-02-07 21:54:33'),
(194, 'admin', 'Nueva Orden de Trabajo: hola', '2016-02-07 21:54:52'),
(195, 'admin', 'Ver Orden de Trabajo: hola', '2016-02-07 21:54:54'),
(196, 'admin', 'Editar Orden de Trabajo: hola', '2016-02-07 21:55:13'),
(197, 'admin', 'Listar Órdenes de Trabajo', '2016-02-07 21:55:22'),
(198, 'admin', 'Listar Órdenes de Trabajo', '2016-02-07 21:55:48'),
(199, 'admin', 'Listar Áreas', '2016-02-19 04:56:43'),
(200, 'admin', 'Listar Expedientes de Proveedor', '2016-02-19 04:56:45'),
(201, 'admin', 'Listar Tipos de Activos', '2016-02-19 04:56:46'),
(202, 'admin', 'Listar Expedientes de Herramienta', '2016-02-19 04:56:49'),
(203, 'admin', 'Listar Tipos de Activos', '2016-02-19 04:57:32'),
(204, 'admin', 'Listar Áreas', '2016-02-19 04:57:34'),
(205, 'admin', 'Listar Expedientes de Proveedor', '2016-02-19 04:57:35'),
(206, 'admin', 'Listar Expedientes de Herramienta', '2016-02-19 04:57:37'),
(207, 'admin', 'Listar Expedientes de Insumo', '2016-02-19 04:57:38'),
(208, 'admin', 'Listar Repuestos', '2016-02-19 04:57:39'),
(209, 'admin', 'Listar Tipos de Prioridad', '2016-02-19 04:57:41'),
(210, 'admin', 'Listar Repuestos', '2016-02-19 04:57:53'),
(211, 'admin', 'Editar Área: Desarrollo1', '2016-02-19 04:59:11'),
(212, 'admin', 'Listar Áreas', '2016-02-19 04:59:13'),
(213, 'admin', 'Nueva Área: prueba', '2016-02-19 04:59:18'),
(214, 'admin', 'Listar Áreas', '2016-02-19 04:59:20'),
(215, 'admin', 'Eliminar Área: prueba', '2016-02-19 04:59:30'),
(216, 'admin', 'Listar Áreas', '2016-02-19 04:59:32'),
(217, 'admin', 'Editar Área: Desarrollo', '2016-02-19 04:59:36'),
(218, 'admin', 'Listar Áreas', '2016-02-19 04:59:38'),
(219, 'admin', 'Listar Áreas', '2016-02-19 05:00:02'),
(220, 'admin', ' ', '2016-02-19 05:00:19'),
(221, 'admin', 'Listar Expedientes de Proveedor', '2016-02-19 05:00:20'),
(222, 'admin', ' ', '2016-02-19 05:00:32'),
(223, 'admin', 'Listar Expedientes de Proveedor', '2016-02-19 05:00:34'),
(224, 'admin', 'Editar Tipo de Activo: XXXXX', '2016-02-19 05:00:58'),
(225, 'admin', 'Listar Tipos de Activos', '2016-02-19 05:00:59'),
(226, 'admin', ' ', '2016-02-19 05:01:23'),
(227, 'admin', 'Listar Expedientes de Herramienta', '2016-02-19 05:01:25'),
(228, 'admin', ' ', '2016-02-19 05:01:44'),
(229, 'admin', 'Listar Expedientes de Insumo', '2016-02-19 05:01:45'),
(230, 'admin', 'Listar Repuestos', '2016-02-19 05:01:55'),
(231, 'admin', 'Listar Repuestos', '2016-02-19 05:01:57'),
(232, 'admin', ' ', '2016-02-19 05:02:14'),
(233, 'admin', 'Listar Expedientes de Insumo', '2016-02-19 05:02:16'),
(234, 'admin', 'Listar Repuestos', '2016-02-19 05:02:20'),
(235, 'admin', 'Listar Repuestos', '2016-02-19 05:02:24'),
(236, 'admin', ' ', '2016-02-19 05:02:35'),
(237, 'admin', 'Listar Expedientes de Insumo', '2016-02-19 05:02:37'),
(238, 'admin', 'Listar Facturas', '2016-02-19 05:02:58'),
(239, 'admin', 'Listar Facturas', '2016-02-19 05:03:03'),
(240, 'admin', 'Editar Factura: 1231', '2016-02-19 05:03:23'),
(241, 'admin', 'Ver Factura: 1231', '2016-02-19 05:03:25'),
(242, 'admin', 'Nuevo Expediente de Activo: PRUEBA', '2016-02-19 05:24:32'),
(243, 'admin', 'Ver Expediente de Activo: PRUEBA', '2016-02-19 05:24:35'),
(244, 'admin', 'Editar Expediente de Activo: PRUEBA', '2016-02-19 05:26:53'),
(245, 'admin', 'Ver Expediente de Activo: PRUEBA', '2016-02-19 05:26:55'),
(246, 'admin', 'Editar Expediente de Activo: PRUEBA', '2016-02-19 05:30:19'),
(247, 'admin', 'Ver Expediente de Activo: PRUEBA', '2016-02-19 05:30:21'),
(248, 'admin', 'Editar Expediente de Activo: PRUEBA', '2016-02-19 05:30:44'),
(249, 'admin', 'Ver Expediente de Activo: PRUEBA', '2016-02-19 05:30:45'),
(250, 'admin', 'Editar Expediente de Activo: PRUEBA', '2016-02-19 05:33:22'),
(251, 'admin', 'Ver Expediente de Activo: PRUEBA', '2016-02-19 05:33:24'),
(252, 'admin', 'Nuevo Expediente de Activo: prueba', '2016-02-19 06:08:24'),
(253, 'admin', 'Ver Expediente de Activo: prueba', '2016-02-19 06:08:26'),
(254, 'admin', 'Editar Expediente de Activo: prueba', '2016-02-19 06:11:29'),
(255, 'admin', 'Ver Expediente de Activo: prueba', '2016-02-19 06:11:31'),
(256, 'admin', 'Editar Expediente de Activo: prueba', '2016-02-19 06:14:37'),
(257, 'admin', 'Editar Expediente de Activo: prueba', '2016-02-19 06:20:08'),
(258, 'admin', 'Editar Expediente de Activo: prueba', '2016-02-19 06:20:42'),
(259, 'admin', 'Listar Expedientes de Activos', '2016-02-19 06:20:47'),
(260, 'admin', 'Listar Expedientes de Activos', '2016-02-19 06:20:50'),
(261, 'admin', 'Editar Expediente de Activo: prueba', '2016-02-19 06:21:15'),
(262, 'admin', 'Editar Expediente de Activo: prueba', '2016-02-19 06:40:50'),
(263, 'admin', 'Ver Expediente de Activo: prueba', '2016-02-19 06:40:53'),
(264, 'admin', 'Editar Expediente de Activo: prueba', '2016-02-19 06:44:17'),
(265, 'admin', 'Editar Expediente de Activo: prueba', '2016-02-19 06:50:28'),
(266, 'admin', 'Ver Expediente de Activo: prueba', '2016-02-19 06:50:30'),
(267, 'admin', 'Editar Expediente de Activo: prueba', '2016-02-19 06:59:41'),
(268, 'admin', 'Listar Expedientes de Activos', '2016-02-19 07:01:10'),
(269, 'admin', 'Listar Expedientes de Activos', '2016-02-19 07:01:13'),
(270, 'admin', 'Editar Expediente de Activo: prueba', '2016-02-19 07:02:21'),
(271, 'admin', 'Listar Expedientes de Activos', '2016-02-19 07:08:53'),
(272, 'admin', 'Listar Expedientes de Activos', '2016-02-19 07:08:56'),
(273, 'admin', 'Editar Expediente de Activo: prueba', '2016-02-19 07:09:17'),
(274, 'admin', 'Editar Expediente de Activo: prueba', '2016-02-19 07:09:27'),
(275, 'admin', 'Ver Expediente de Activo: prueba', '2016-02-19 07:09:29'),
(276, 'admin', 'Nuevo Expediente de Activo: PRUEBITA', '2016-02-19 07:23:16'),
(277, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-19 07:23:18'),
(278, 'admin', 'Nuevo Plan de Mantenimiento: REPARACION DE CALDERA A PRUEBITA', '2016-02-19 07:26:05'),
(279, 'admin', 'Listar Planes de Mantenimiento', '2016-02-19 07:26:07'),
(280, 'admin', 'Listar Expedientes de Activos', '2016-02-19 07:26:22'),
(281, 'admin', 'Listar Expedientes de Activos', '2016-02-19 07:26:24'),
(282, 'admin', 'Listar Expedientes de Activos', '2016-02-19 07:29:15'),
(283, 'admin', 'Listar Expedientes de Activos', '2016-02-19 07:29:17'),
(284, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-19 07:29:23'),
(285, 'admin', 'Listar Planes de Mantenimiento', '2016-02-19 07:30:27'),
(286, 'admin', 'Ver Plan de Manteniento: REPARACION DE CALDERA A PRUEBITA', '2016-02-19 07:30:34'),
(287, 'admin', 'Editar Plan de Mantenimiento: REPARACION DE CALDERA A PRUEBITA', '2016-02-19 07:31:54'),
(288, 'admin', 'Listar Planes de Mantenimiento', '2016-02-19 07:31:56'),
(291, 'admin', 'Editar Plan de Mantenimiento: REPARACION DE CALDERA A PRUEBITA1', '2016-02-19 07:33:19'),
(292, 'admin', 'Listar Planes de Mantenimiento', '2016-02-19 07:33:21'),
(293, 'admin', 'Nuevo Plan de Mantenimiento: PRRR', '2016-02-19 07:33:47'),
(294, 'admin', 'Listar Planes de Mantenimiento', '2016-02-19 07:33:49'),
(295, 'admin', 'Listar Expedientes de Activos', '2016-02-19 07:34:01'),
(296, 'admin', 'Listar Expedientes de Activos', '2016-02-19 07:34:04'),
(297, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-19 07:34:12'),
(298, 'admin', 'Listar Expedientes de Accion', '2016-02-19 07:35:11'),
(299, 'admin', '', '2016-02-19 07:35:28'),
(300, 'admin', 'Listar Expedientes de Accion', '2016-02-19 07:35:31'),
(301, 'admin', 'Listar Expedientes de Procedimiento', '2016-02-19 07:35:58'),
(302, 'admin', '', '2016-02-19 07:37:42'),
(303, 'admin', ' ', '2016-02-19 07:37:44'),
(304, 'admin', ' ', '2016-02-19 07:37:59'),
(305, 'admin', ' ', '2016-02-19 07:38:06'),
(306, 'admin', 'Listar Órdenes de Trabajo', '2016-02-19 07:38:58'),
(307, 'admin', 'Nueva Orden de Trabajo: PRUEBA Numero 1', '2016-02-19 07:42:47'),
(308, 'admin', 'Ver Orden de Trabajo: PRUEBA Numero 1', '2016-02-19 07:42:49'),
(309, 'admin', 'Editar Orden de Trabajo: PRUEBA Numero 1', '2016-02-19 07:43:25'),
(310, 'admin', 'Listar Órdenes de Trabajo', '2016-02-19 07:43:31'),
(311, 'admin', 'Listar Roles de Usuario', '2016-02-19 07:44:14'),
(312, 'admin', 'Listar Usuarios del Sistema', '2016-02-19 07:44:19'),
(313, 'admin', 'Ver Registro de Trazas', '2016-02-19 07:44:21'),
(314, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:24:55'),
(315, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:24:58'),
(316, 'admin', 'Listar Expedientes de Activos para Reporte', '2016-02-22 22:25:04'),
(317, 'admin', 'Listar Expedientes de Activos para Reporte', '2016-02-22 22:25:08'),
(318, 'admin', 'Listar Expedientes de Activos para Reporte', '2016-02-22 22:25:13'),
(319, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:25:29'),
(320, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:25:32'),
(321, 'admin', 'Listar Órdenes de Trabajo', '2016-02-22 22:25:35'),
(322, 'admin', 'Listar Ordenes para Reporte', '2016-02-22 22:25:40'),
(323, 'admin', 'Listar Expedientes de Procedimiento', '2016-02-22 22:25:56'),
(324, 'admin', 'Ver Registro de Trazas', '2016-02-22 22:26:10'),
(325, 'admin', 'Listar Usuarios del Sistema', '2016-02-22 22:26:12'),
(326, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:31:42'),
(327, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:31:47'),
(328, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:32:05'),
(329, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:32:08'),
(330, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:33:14'),
(331, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:33:16'),
(332, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:40:29'),
(333, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:40:31'),
(334, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:41:40'),
(335, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:41:43'),
(336, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:42:08'),
(337, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:42:11'),
(338, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:46:32'),
(339, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:46:35'),
(340, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:47:06'),
(341, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:47:09'),
(342, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:49:38'),
(343, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:49:41'),
(344, 'admin', 'Borrar Expediente de Activo: prueba', '2016-02-22 22:49:47'),
(345, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:49:47'),
(346, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:49:50'),
(347, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:51:05'),
(348, 'admin', 'Listar Expedientes de Activos', '2016-02-22 22:51:08'),
(349, 'admin', 'Listar Expedientes de Activos', '2016-02-29 05:35:39'),
(350, 'admin', 'Listar Expedientes de Activos', '2016-02-29 05:35:42'),
(351, 'admin', 'Editar Expediente de Activo: PRUEBITA', '2016-02-29 05:37:27'),
(352, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 05:37:29'),
(353, 'admin', 'Listar Expedientes de Activos', '2016-02-29 06:06:22'),
(354, 'admin', 'Listar Expedientes de Activos', '2016-02-29 06:06:25'),
(355, 'admin', 'Editar Expediente de Activo: PRUEBITA', '2016-02-29 06:06:49'),
(356, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 06:06:51'),
(357, 'admin', 'Editar Expediente de Activo: PRUEBITA', '2016-02-29 06:07:48'),
(358, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 06:07:50'),
(359, 'admin', 'Editar Expediente de Activo: PRUEBITA', '2016-02-29 06:27:22'),
(360, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 06:27:25'),
(361, 'admin', 'Listar Expedientes de Activos', '2016-02-29 10:18:08'),
(362, 'admin', 'Listar Expedientes de Activos', '2016-02-29 10:18:11'),
(363, 'admin', 'Editar Expediente de Activo: PRUEBITA', '2016-02-29 10:19:35'),
(364, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:19:37'),
(365, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:22:56'),
(366, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:23:29'),
(367, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:24:19'),
(368, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:25:10'),
(369, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:26:26'),
(370, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:27:01'),
(371, 'admin', 'Editar Expediente de Activo: PRUEBITA', '2016-02-29 10:28:08'),
(372, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:28:09'),
(373, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:29:02'),
(374, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:29:54'),
(375, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:30:51'),
(376, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:31:51'),
(377, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:33:18'),
(378, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:34:12'),
(379, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:34:18'),
(380, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:36:39'),
(381, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:36:51'),
(382, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:37:53'),
(383, 'admin', 'Editar Expediente de Activo: PRUEBITA', '2016-02-29 10:39:57'),
(384, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:39:58'),
(385, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:40:03'),
(386, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:40:48'),
(387, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:42:25'),
(388, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:42:57'),
(389, 'admin', 'Editar Expediente de Activo: PRUEBITA', '2016-02-29 10:44:19'),
(390, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-02-29 10:44:21'),
(391, 'admin', 'Listar Expedientes de Activos', '2016-03-01 06:50:18'),
(392, 'admin', 'Listar Expedientes de Activos', '2016-03-01 06:50:20'),
(393, 'admin', 'Editar Expediente de Activo: PRUEBITA', '2016-03-01 06:52:30'),
(394, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-03-01 06:52:32'),
(395, 'admin', 'Editar Expediente de Activo: PRUEBITA', '2016-03-01 06:54:12'),
(396, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-03-01 06:54:14'),
(397, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-03-01 06:54:18'),
(398, 'admin', 'Editar Expediente de Activo: PRUEBITA', '2016-03-01 06:57:44'),
(399, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-03-01 06:57:46'),
(400, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-03-01 06:57:49'),
(401, 'admin', 'Editar Expediente de Activo: PRUEBITA', '2016-03-01 06:59:45'),
(402, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-03-01 06:59:46'),
(403, 'admin', 'Ver Expediente de Activo: PRUEBITA', '2016-03-01 06:59:53'),
(404, 'admin', 'Listar Expedientes de Activos', '2016-04-09 03:15:54'),
(405, 'admin', 'Listar Expedientes de Activos', '2016-04-09 03:16:02'),
(406, 'admin', 'Listar Expedientes de Activos para Reporte', '2016-04-09 03:16:19'),
(407, 'admin', 'Listar Expedientes de Activos', '2016-04-09 03:19:18'),
(408, 'admin', 'Listar Expedientes de Activos', '2016-04-09 03:19:23'),
(409, 'admin', 'Listar Expedientes de Activos', '2016-04-09 03:19:50'),
(410, 'admin', 'Listar Expedientes de Activos', '2016-04-09 03:19:53'),
(411, 'admin', 'Listar Expedientes de Activos', '2016-04-09 03:20:51'),
(412, 'admin', 'Listar Expedientes de Activos', '2016-04-09 03:20:54'),
(413, 'admin', 'Listar Expedientes de Activos', '2016-04-09 03:21:34'),
(414, 'admin', 'Listar Expedientes de Activos', '2016-04-09 03:21:36'),
(415, 'admin', 'Listar Expedientes de Activos', '2016-04-09 03:22:57'),
(416, 'admin', 'Listar Tipos de Activos', '2016-04-09 04:53:08'),
(417, 'admin', 'Listar Expedientes de Activos', '2016-04-09 04:54:38'),
(418, 'admin', 'Listar Expedientes de Activos', '2016-04-09 04:54:41'),
(419, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:18:31'),
(420, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:18:51'),
(421, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:20:16'),
(422, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:24:04'),
(423, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:24:41'),
(424, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:24:43'),
(425, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:25:43'),
(426, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:25:47'),
(427, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:25:55'),
(428, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:26:24'),
(429, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:26:27'),
(430, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:26:47'),
(431, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:27:06'),
(432, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:27:09'),
(433, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:27:26'),
(434, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:27:29'),
(435, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:30:40'),
(436, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:30:42'),
(437, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:30:57'),
(438, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:31:01'),
(439, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:31:25'),
(440, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:32:01'),
(441, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:32:04'),
(442, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:34:27'),
(443, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:34:30'),
(444, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:34:36'),
(445, 'admin', 'Listar Expedientes de Activos', '2016-04-09 05:34:41');

-- --------------------------------------------------------

--
-- Table structure for table `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `roles_id` int(11) DEFAULT NULL,
  `password` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Usuario` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Salt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_EDD889C138C751C4` (`roles_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=5 ;

--
-- Dumping data for table `usuario`
--

INSERT INTO `usuario` (`id`, `roles_id`, `password`, `Usuario`, `Salt`) VALUES
(2, 5, 'WO2vDSWwDcA6pkrkCtwg8NVEcXRac5L8TyUsyHl6e5nTF0jHyx0r3jG+P2L+PNQXFrN1nUMsO4G5lF93SWoOIA==', 'gisselle', 'a6504e3ffb8e961b5d048c8650482962'),
(3, 7, 'kxpmym17h52SlqTOnW1QZ4bjcky32aEfpofsz9qFA7c14D5y/X2MB1bWU7V40+KVQGhYVHmOioqZombGt9i/Vw==', 'almacenero1', '47aaf727772d0d4e967de83f761f2034'),
(4, 6, '1w2jV25aLpMLBUV9DL97lylMO9m0LZv8BJ7alS12aooxtzAdpRII27lAioURR1l0ajKJz/bpKQxqJm7+M1+tQA==', 'rolando', '9e8b702c47dfca278833fe957de1a615');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `actividad`
--
ALTER TABLE `actividad`
  ADD CONSTRAINT `FK_F033FA513BCBD34` FOREIGN KEY (`tipoActividad_id`) REFERENCES `tipoactividad` (`id`),
  ADD CONSTRAINT `FK_F033FA5937FC699` FOREIGN KEY (`planMtto_id`) REFERENCES `planmtto` (`id`);

--
-- Constraints for table `activo`
--
ALTER TABLE `activo`
  ADD CONSTRAINT `FK_AC67102A328AFFA9` FOREIGN KEY (`tipoActivo_id`) REFERENCES `tipoactivo` (`id`),
  ADD CONSTRAINT `FK_AC67102ABD0F409C` FOREIGN KEY (`area_id`) REFERENCES `area` (`id`),
  ADD CONSTRAINT `FK_AC67102AF04F795F` FOREIGN KEY (`factura_id`) REFERENCES `factura` (`id`);

--
-- Constraints for table `estop`
--
ALTER TABLE `estop`
  ADD CONSTRAINT `FK_5BA7CD2C487E62A3` FOREIGN KEY (`activo_id`) REFERENCES `activo` (`id`);

--
-- Constraints for table `factura`
--
ALTER TABLE `factura`
  ADD CONSTRAINT `FK_36569995CB305D73` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`id`);

--
-- Constraints for table `ordentrabajo`
--
ALTER TABLE `ordentrabajo`
  ADD CONSTRAINT `FK_3BF2895C937FC699` FOREIGN KEY (`planMtto_id`) REFERENCES `planmtto` (`id`);

--
-- Constraints for table `ordentrabajo_procedimiento`
--
ALTER TABLE `ordentrabajo_procedimiento`
  ADD CONSTRAINT `FK_1E60AF3F7D8D9FA3` FOREIGN KEY (`ordentrabajo_id`) REFERENCES `ordentrabajo` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_1E60AF3FF696A255` FOREIGN KEY (`procedimiento_id`) REFERENCES `procedimiento` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `otrep`
--
ALTER TABLE `otrep`
  ADD CONSTRAINT `FK_DF6B1B4E4C3B689E` FOREIGN KEY (`repuesto_id`) REFERENCES `repuesto` (`id`),
  ADD CONSTRAINT `FK_DF6B1B4EF696A255` FOREIGN KEY (`procedimiento_id`) REFERENCES `procedimiento` (`id`);

--
-- Constraints for table `persona`
--
ALTER TABLE `persona`
  ADD CONSTRAINT `FK_9E588F07DB38439E` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`id`);

--
-- Constraints for table `planmtto`
--
ALTER TABLE `planmtto`
  ADD CONSTRAINT `FK_35609FBA487E62A3` FOREIGN KEY (`activo_id`) REFERENCES `activo` (`id`),
  ADD CONSTRAINT `FK_35609FBACE797A84` FOREIGN KEY (`tipoPrioridad_id`) REFERENCES `tipoprioridad` (`id`);

--
-- Constraints for table `procedimiento_accion`
--
ALTER TABLE `procedimiento_accion`
  ADD CONSTRAINT `FK_C271E3F3F4B5275` FOREIGN KEY (`accion_id`) REFERENCES `accion` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_C271E3FF696A255` FOREIGN KEY (`procedimiento_id`) REFERENCES `procedimiento` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `proher`
--
ALTER TABLE `proher`
  ADD CONSTRAINT `FK_8513AE24B2C900C2` FOREIGN KEY (`herramienta_id`) REFERENCES `herramienta` (`id`),
  ADD CONSTRAINT `FK_8513AE24F696A255` FOREIGN KEY (`procedimiento_id`) REFERENCES `procedimiento` (`id`);

--
-- Constraints for table `proins`
--
ALTER TABLE `proins`
  ADD CONSTRAINT `FK_10222D4ECE208F97` FOREIGN KEY (`insumo_id`) REFERENCES `insumo` (`id`),
  ADD CONSTRAINT `FK_10222D4EF696A255` FOREIGN KEY (`procedimiento_id`) REFERENCES `procedimiento` (`id`);

--
-- Constraints for table `proper`
--
ALTER TABLE `proper`
  ADD CONSTRAINT `FK_97265CECF5F88DB9` FOREIGN KEY (`persona_id`) REFERENCES `persona` (`id`),
  ADD CONSTRAINT `FK_97265CECF696A255` FOREIGN KEY (`procedimiento_id`) REFERENCES `procedimiento` (`id`);

--
-- Constraints for table `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `FK_EDD889C138C751C4` FOREIGN KEY (`roles_id`) REFERENCES `rol` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
