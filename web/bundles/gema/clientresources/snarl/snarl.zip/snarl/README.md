# Snarl

Growl style notifications for your web app.


## Documentation

Snarl is using Jekyll to generate the documentation site.

For now, check the site at [hoxxep.github.io/snarl](https://hoxxep.github.io/snarl) for usage docs.


## License
Snarl is maintained by [Liam Gray](http://hoxxep.github.io), and released under the [MIT license](https://github.com/hoxxep/Snarl/blob/master/LICENSE). 

Copyright &copy; 2014 Liam Gray. All rights reserved.