# Changelog

#### 1.1.0

* Support UMD
* Use Babel 6 and replace let with const where possible
* Remove bundled ES6 polyfill (include it from elsewhere if you need it)
